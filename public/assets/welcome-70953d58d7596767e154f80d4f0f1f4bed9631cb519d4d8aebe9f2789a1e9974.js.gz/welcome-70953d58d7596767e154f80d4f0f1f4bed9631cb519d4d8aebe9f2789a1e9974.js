$(document).on('turbolinks:load', function(){
	$('.search_index').niceSelect();
});
